int DeviceWritePage(int mc_num, void *buf, u32 page_num);
int DeviceReadPage(int mc_num, void *buf, u32 page_num);
void DeviceShutdown(void);
