#define CNF_PATH_LEN_MAX 64

int ps2cnfGetBootFile(const char *path, char *bootfile);
