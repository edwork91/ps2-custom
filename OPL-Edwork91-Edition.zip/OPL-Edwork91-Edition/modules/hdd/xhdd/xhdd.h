int ata_device_set_transfer_mode(int device, int type, int mode);
int ata_device_set_write_cache(int device, int enable);
int hdproata_device_set_transfer_mode(int device, int type, int mode);
int hdproata_device_set_write_cache(int device, int enable);
