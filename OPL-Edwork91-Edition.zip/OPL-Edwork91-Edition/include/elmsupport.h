#ifndef __ELM_SUPPORT_H
#define __ELM_SUPPORT_H

#include "include/iosupport.h"

#define ELM_MODE_UPDATE_DELAY 240

void elmInit();
item_list_t *elmGetObject(int initOnly);

#endif
