void SmbInitHashPassword(server_specs_t *ss);
