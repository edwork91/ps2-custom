#ifndef __IOPRP_img__
#define __IOPRP_img__

unsigned int size_IOPRP_img = 0;
unsigned char IOPRP_img[] __attribute__((aligned(16))) = {
};

#endif
