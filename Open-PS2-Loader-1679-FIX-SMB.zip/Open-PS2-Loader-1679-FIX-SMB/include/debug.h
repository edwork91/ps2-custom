#ifndef __DEBUG_H
#define __DEBUG_H

int debugSetActive(void);
void debugApplyConfig(void);

#endif
