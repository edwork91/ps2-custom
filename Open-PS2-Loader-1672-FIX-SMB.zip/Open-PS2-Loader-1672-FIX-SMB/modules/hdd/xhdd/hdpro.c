#include <atad.h>
#include <atahw.h>
#include <speedregs.h>

#include "opl-hdd-ioctl.h"
#include "xhdd.h"

int hdproata_device_set_transfer_mode(int device, int type, int mode)
{
    return 0;
}
