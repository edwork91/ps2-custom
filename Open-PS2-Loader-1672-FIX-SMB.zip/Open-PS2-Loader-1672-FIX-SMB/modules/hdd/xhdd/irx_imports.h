#ifndef IOP_IRX_IMPORTS_H
#define IOP_IRX_IMPORTS_H

#include <irx.h>

#include <atad.h>
#include <ioman.h>
#include <sysclib.h>

#endif
