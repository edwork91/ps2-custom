#ifndef _EXTERNAL_
#define _EXTERNAL_

//externs


#endif