Here comes usbd.irx from the source code of Launchelf 3.41

For some reason, this is the only free usbd.irx that works in the PS3.