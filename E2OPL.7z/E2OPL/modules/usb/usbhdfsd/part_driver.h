#ifndef _PART_DRIVER_H
#define _PART_DRIVER_H 1

int part_connect(mass_dev* dev);
void part_disconnect(mass_dev* dev);

#endif

