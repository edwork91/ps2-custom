#ifndef _INTRMAN_ADD_H_
#define _INTRMAN_ADD_H_

void *intrman_14(void *func, void *arg1, void *arg2, void *arg3);
#define I_intrman_14 DECLARE_IMPORT(14, intrman_14)

#endif
