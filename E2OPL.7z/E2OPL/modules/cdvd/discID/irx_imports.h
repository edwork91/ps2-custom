#ifndef IOP_IRX_IMPORTS_H
#define IOP_IRX_IMPORTS_H

#include <irx.h>

#include <ioman.h>
#include <sysclib.h>
#include <thsemap.h>

#endif
