/*
  Copyright (c) 2010  jimmikaelkael <jimmikaelkael@wanadoo.fr>
  Licenced under Academic Free License version 3.0
*/

#ifndef UDPTTY_H
#define UDPTTY_H

#include "lanman.h"

void ttyInit(g_param_t *gparam);

#endif /* UDPTTY_H */
