inline int HandleRxIntr(struct SmapDriverData *SmapDrivPrivData);
int SMAPSendPacket(const void *data, unsigned int length);

