/*
  Copyright 2009-2010, Ifcaro, jimmikaelkael & Polo
  Copyright 2006-2008 Polo
  Licenced under Academic Free License version 3.0
  Review Open-Ps2-Loader README & LICENSE files for further details.
  
  Some parts of the code are taken from HD Project by Polo
*/

#ifndef DES_H
#define DES_H

unsigned char *DES(unsigned char *key, unsigned char *message, unsigned char *cipher);

#endif /* DES */
