#ifndef __DEBUG_H
#define __DEBUG_H

int debugSetActive(void);

#endif
