#ifndef __APP_SUPPORT_H
#define __APP_SUPPORT_H

#include "include/iosupport.h"

void appInit();
item_list_t* appGetObject(int initOnly);

#endif
