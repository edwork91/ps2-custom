#ifndef __INTEGERS_H
#define __INTEGERS_H

typedef unsigned char uint8_t;
typedef unsigned long int uint32_t;

#endif
